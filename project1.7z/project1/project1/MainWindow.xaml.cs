﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System;

namespace project1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public double result;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void OneButton_Click(object sender, RoutedEventArgs e)
        {
            EnterTextBox.Text += "1";
        }

        private void TwoButton_Click(object sender, RoutedEventArgs e)
        {
            EnterTextBox.Text += "2";
        }

        private void ThreeButton_Click(object sender, RoutedEventArgs e)
        {
            EnterTextBox.Text += "3";
        }

        private void FourButton_Click(object sender, RoutedEventArgs e)
        {
            EnterTextBox.Text += "4";
        }

        private void FiveButton_Click(object sender, RoutedEventArgs e)
        {
            EnterTextBox.Text += "5";
        }

        private void SixButton_Click(object sender, RoutedEventArgs e)
        {
            EnterTextBox.Text += "6";
        }

        private void SevenButton_Click(object sender, RoutedEventArgs e)
        {
            EnterTextBox.Text += "7";
        }

        private void EightButton_Click(object sender, RoutedEventArgs e)
        {
            EnterTextBox.Text += "8";
        }

        private void NineButton_Click(object sender, RoutedEventArgs e)
        {
            EnterTextBox.Text += "9";
        }

        private void ZeroButton_Click(object sender, RoutedEventArgs e)
        {
            EnterTextBox.Text += "0";
        }

        private void DotButton_Click(object sender, RoutedEventArgs e)
        {
            EnterTextBox.Text += ".";
        }

        private void MinusButton_Click(object sender, RoutedEventArgs e)
        {
            ZnakLabel.Content = "-";
            EnteredNumberLabel.Content = EnterTextBox.Text.ToString();
            EnterTextBox.Text = "";
        }

        private void PlusButton_Click(object sender, RoutedEventArgs e)
        {
            ZnakLabel.Content = "+";
            EnteredNumberLabel.Content = EnterTextBox.Text.ToString();
            EnterTextBox.Text = "";
        }

        private void MultipleButton_Click(object sender, RoutedEventArgs e)
        {
            ZnakLabel.Content = "*";
            EnteredNumberLabel.Content = EnterTextBox.Text.ToString();
            EnterTextBox.Text = "";
        }

        private void DivButton_Click(object sender, RoutedEventArgs e)
        {
            ZnakLabel.Content = "÷";
            EnteredNumberLabel.Content = EnterTextBox.Text.ToString();
            EnterTextBox.Text = "";
        }

        private void EnterButton_Click(object sender, RoutedEventArgs e)
        {
            switch(ZnakLabel.Content)
            {
                case "-":
                    {
                        result = double.Parse(EnteredNumberLabel.Content.ToString()) - double.Parse(EnterTextBox.Text.ToString());
                        EnterTextBox.Text = result.ToString();
                        EnteredNumberLabel.Content = "";
                        ZnakLabel.Content = "";
                        break;
                    }
                case "+":
                    {
                        result = double.Parse(EnteredNumberLabel.Content.ToString()) + double.Parse(EnterTextBox.Text.ToString());
                        EnterTextBox.Text = result.ToString();
                        EnteredNumberLabel.Content = "";
                        ZnakLabel.Content = "";
                        break;
                    }
                case "*":
                    {
                        result = double.Parse(EnteredNumberLabel.Content.ToString()) * double.Parse(EnterTextBox.Text.ToString());
                        EnterTextBox.Text = result.ToString();
                        EnteredNumberLabel.Content = "";
                        ZnakLabel.Content = "";
                        break;
                    }
                case "÷":
                    {
                        result = double.Parse(EnteredNumberLabel.Content.ToString()) / double.Parse(EnterTextBox.Text.ToString());
                        EnterTextBox.Text = result.ToString();
                        EnteredNumberLabel.Content = "";
                        ZnakLabel.Content = "";
                        break;
                    }
                case "^":
                    {
                        result = Math.Pow(double.Parse(EnteredNumberLabel.Content.ToString()), double.Parse(EnterTextBox.Text.ToString()));
                        EnterTextBox.Text = result.ToString();
                        EnteredNumberLabel.Content = "";
                        ZnakLabel.Content = "";
                        break;
                    }
                case "L":
                    {
                        result = Math.Log(double.Parse(EnteredNumberLabel.Content.ToString()), double.Parse(EnterTextBox.Text.ToString()));
                        EnterTextBox.Text = result.ToString();
                        EnteredNumberLabel.Content = "";
                        ZnakLabel.Content = "";
                        break;
                    }
                case "^√":
                    result = Math.Pow(double.Parse(EnterTextBox.Text.ToString()), double.Parse(EnteredNumberLabel.Content.ToString()) / double.Parse(ThierdNumberLabel.Content.ToString()));
                    EnterTextBox.Text = result.ToString();
                    EnteredNumberLabel.Content = "";
                    ZnakLabel.Content = "";
                    ThierdNumberLabel.Content = "";
                    break;

            }
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            EnteredNumberLabel.Content = "";
            ZnakLabel.Content = "";
            EnterTextBox.Text = "";
        }

        private void DvoichButton_Click(object sender, RoutedEventArgs e)
        {
            string NumberSystem = Convert.ToString(int.Parse(EnterTextBox.Text.ToString()), 2);
            EnterTextBox.Text = NumberSystem;
        }

        private void VosmirichButton_Click(object sender, RoutedEventArgs e)
        {
            string NumberSystem = Convert.ToString(int.Parse(EnterTextBox.Text.ToString()), 8);
            EnterTextBox.Text = NumberSystem;
        }

        private void DesitichFromVosButton_Click(object sender, RoutedEventArgs e)
        {
            string NumberSystem = Convert.ToString(Convert.ToInt32(EnterTextBox.Text.ToString(), 8), 10);
            EnterTextBox.Text = NumberSystem;
        }

        private void DesitichFromDvoiButton_Click(object sender, RoutedEventArgs e)
        {
            string NumberSystem = Convert.ToString(Convert.ToInt32(EnterTextBox.Text.ToString(), 2), 10);
            EnterTextBox.Text = NumberSystem;
        }

        private void ExpButton_Click(object sender, RoutedEventArgs e)
        {
            result = Math.Exp(double.Parse(EnterTextBox.Text));
            EnterTextBox.Text = result.ToString();
        }

        private void CorenButton_Click(object sender, RoutedEventArgs e)
        {
            result = Math.Sqrt(double.Parse(EnterTextBox.Text));
            EnterTextBox.Text = result.ToString();
        }

        private void StepButton_Click(object sender, RoutedEventArgs e)
        {
            ZnakLabel.Content = "^";
            EnteredNumberLabel.Content = EnterTextBox.Text.ToString();
            EnterTextBox.Text = "";
        }

        private void PiButton_Click(object sender, RoutedEventArgs e)
        {
            result = Math.PI;
            EnterTextBox.Text = result.ToString();
        }

        private void LnButton_Click(object sender, RoutedEventArgs e)
        {
            result = Math.Log(double.Parse(EnterTextBox.Text));
            EnterTextBox.Text = result.ToString();
        }

        private void LogButton_Click(object sender, RoutedEventArgs e)
        {
            ZnakLabel.Content = "L";
            EnteredNumberLabel.Content = EnterTextBox.Text.ToString();
            EnterTextBox.Text = "";
        }

        private void FactorialButton_Click(object sender, RoutedEventArgs e)
        {
            result = 1;
            for (int i = 1; i <= int.Parse(EnterTextBox.Text); i++)
                result *= i;
            EnterTextBox.Text = result.ToString();

        }


        private void TanButton_Click(object sender, RoutedEventArgs e)
        {
            result = Math.Tan(double.Parse(EnterTextBox.Text)*Math.PI/180);
            EnterTextBox.Text = result.ToString();
        }

        private void CosButton_Click(object sender, RoutedEventArgs e)
        {
            result = Math.Cos(double.Parse(EnterTextBox.Text) * Math.PI / 180);
            EnterTextBox.Text = result.ToString();
        }

        private void SinButton_Click(object sender, RoutedEventArgs e)
        {
            result = Math.Sin(double.Parse(EnterTextBox.Text) * Math.PI / 180);
            EnterTextBox.Text = result.ToString();
        }

        private void ASinButton_Click(object sender, RoutedEventArgs e)
        {
            result = Math.Asin(double.Parse(EnterTextBox.Text) * Math.PI / 180);
            EnterTextBox.Text = result.ToString();
        }

        private void ACosButton_Click(object sender, RoutedEventArgs e)
        {
            result = Math.Acos(double.Parse(EnterTextBox.Text) * Math.PI / 180);
            EnterTextBox.Text = result.ToString();
        }

        private void ATanButton_Click(object sender, RoutedEventArgs e)
        {
            result = Math.Atan(double.Parse(EnterTextBox.Text) * Math.PI / 180);
            EnterTextBox.Text = result.ToString();
        }

        private void SquartStepButton_Click(object sender, RoutedEventArgs e)
        {
            ZnakLabel.Content = "^√";
            EnteredNumberLabel.Content = EnterTextBox.Text.ToString();
            EnterTextBox.Text = "Число";
            EnteredNumberLabel.Content = "Степень числа";
            ThierdNumberLabel.Content = "Степень корня";
        }

        private void UpButton_Click(object sender, RoutedEventArgs e)
        {
            ThierdNumberLabel.Content = EnteredNumberLabel.Content;
            EnteredNumberLabel.Content = EnterTextBox.Text;
            EnterTextBox.Text = "";
            
        }

        private void UpButton_Copy_Click(object sender, RoutedEventArgs e)
        {
            EnterTextBox.Text = EnteredNumberLabel.Content.ToString();
            EnteredNumberLabel.Content = ThierdNumberLabel.Content;
            ThierdNumberLabel.Content = "";
        }
    }
}
